﻿<?php
	if(!($conexion=mysqli_connect('127.0.0.1', 'root','','escuela')))die("Fallo en conexion!!!, error:".mysql_connect_error());

	$respuesta=array();

	if ($_SERVER['REQUEST_METHOD']=='POST') { 

		$cadena_json = file_get_contents('php://input');

		$datos= json_decode($cadena_json, true); 

		$carrera=$datos['c'];
	}

		$sql="SELECT * FROM alumnos WHERE Carrera_Alumno LIKE'$carrera'";

		echo json_encode($sql);
		
		$resultado=mysqli_query($conexion,$sql);

		if ($resultado) {
			$respuesta['exito']=1;
			$respuesta['msj']="Busqueda correcta";
			echo json_encode($respuesta);
		} else {
			$respuesta['exito']=0;
			$respuesta['msj']="Busqueda incorrecta";
			json_encode($respuesta);
		}

?>